package comportement;

import projets.Archer;
import projets.Joueur;

public class RecruterArcher extends Recruter
{
	public void creerUnite(Joueur j)
	{
			Archer archer = null;
			archer = new Archer();
		    if (consommerRessources(j,archer) == true)
		    	{
		    	j.addUnite(archer);
		    	}
	    
	}
}
