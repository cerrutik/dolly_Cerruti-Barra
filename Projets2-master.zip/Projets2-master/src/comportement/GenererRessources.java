package comportement;

import projets.Joueur;

public interface GenererRessources
{
	public void generer(Joueur j);
}
