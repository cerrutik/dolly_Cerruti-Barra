package comportement;

import projets.*;


public class RecruterCavalier extends Recruter
{
	public void creerUnite(Joueur j)
	{
			Cavalier cav = new Cavalier();
		    if (consommerRessources(j,cav) == true)
		    	{
		    	j.addUnite(cav);
		    	}

	    
	}
}
