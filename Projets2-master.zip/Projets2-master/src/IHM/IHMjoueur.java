package IHM;

import projets.Terrain;





public class IHMjoueur {

	public static void main(String[] args) {
	
		Fenetre fen = new Fenetre();
	  //Terrain ter = new Terrain();
	  
		
		
	}

}
