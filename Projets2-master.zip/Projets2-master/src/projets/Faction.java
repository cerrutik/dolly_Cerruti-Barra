 package projets;
/**
 * 
 * @author Inconnu
 *
 */
public class Faction
{
	
	private String  nomFaction;
	
}
